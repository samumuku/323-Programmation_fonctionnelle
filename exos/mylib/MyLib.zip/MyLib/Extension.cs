﻿using System.Runtime.InteropServices.JavaScript;

namespace MyLib;

public static class Extension
{
    private static Random _random = new Random();

    public static int ReadInt(this string prompt)
    {
        do
        {
            Console.Write(prompt);
            if(int.TryParse(Console.ReadLine(), out var result))
                return result;
            
            "Veuillez entrer un nombre SVP.\n".Write(ConsoleColor.Red);
        } while (true);
    }

    public static void Write(this string message,ConsoleColor? color=null)
    {
        var previousColor = Console.ForegroundColor;
        if (color.HasValue)
        {
            Console.ForegroundColor = color.Value;
        }
        Console.Write(message);
        Console.ForegroundColor = previousColor;
    }

    public static int ToIntSafe(this string input,int defaultValue = 0)
    {
        if (int.TryParse(input, out int result)) return result;
        return defaultValue;
    }

    public static string RandomString(this Random random,int count =1)
    {
        var characters = Enumerable
            .Range(66, 25) // ASCII chars from 'B' (66) to 'Z' (90)
            .Concat(Enumerable.Range(100, 10)) // ASCII chars from 'd' (100) to 'm' (109)
            .Select(number => Convert.ToChar(number));
            
        return new string(
            Enumerable.Range(0, count)
            .Select(_ => characters.ElementAt(_random.Next(characters.Count()))) 
            .ToArray());
    }
    
    public static bool RandomBool(this Random random)
    {
        return random.Next(2) == 0;
    }
}