﻿//Entrées

using MyLib;

int year = "Année de naissance: ".ReadInt();
$"Vous avez {DateTime.Now.Year-year} ans\n".Write(ConsoleColor.Green);

// Conversions
string input = "123456789101121314151665646548432199999";
int number = input.ToIntSafe();
Console.WriteLine($"{input} converti en {number}");
Console.WriteLine($"Pas un nombre, valeur par défaut : {"notANumber".ToIntSafe()}");
Console.WriteLine($"Pas un nombre, valeur par défaut spécifique (-1) : {"notANumber".ToIntSafe(-1)}");

//Random
var random = new Random();
string randomStr = random.RandomString(8);
Console.WriteLine($"Chaîne aléatoire : {randomStr}");
bool randomBool = random.RandomBool();
Console.WriteLine($"Booléen aléatoire: {randomBool}");